#include <iostream>
#include <iomanip>
using namespace std;

int main() {
  const int SIZE = 12;
  int arrayInt [SIZE] = {23,14,65,3,19,2,71,12,8,61,5,25};

  int min;
  int dummy;

  for (int i = 0; i < SIZE-1; i++) {
    min = i;
    for (int j = i+1; j < SIZE; j++) {
      if (arrayInt[j] < arrayInt[min]) {
        min = j;
      }
    }
    if (min != i) {
      dummy = arrayInt[i];
      arrayInt[i] = arrayInt[min];
      arrayInt[min] = dummy;
    }

    for (int k = 0; k < SIZE; k++) {
      cout << arrayInt[k] << " ";
    }
    cout << endl;
  }
}