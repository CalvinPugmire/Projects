#pragma once
#include <string>
#include <sstream>
#include "LinkedListInterface.h"

using namespace std;

template<class T>
class LinkedList: public LinkedListInterface<T>
{
private:
	struct Node {
	 T data; // The data we are storing
	 Node* next; // A pointer to the next Node 
	 Node(const T& the_data, Node* next_val = NULL) :
	   data(the_data) {next = next_val;}
	};
	Node *mylist;
	int num_items;

public:

	LinkedList(void) {
    mylist = NULL;
		num_items = 0;
		//cout << "In constructor"<<endl;
  };

	~LinkedList(void) {
    //cout << "In destructor"<<endl;
		while(mylist != NULL) {
			Node *current = mylist;
			mylist = mylist->next;
			delete current;
      num_items--;
		}
  };

	/*
	insertHead

	A node with the given value should be inserted at the beginning of the list.

	Do not allow duplicate values in the list.
	*/
	void insertHead(T value) {
    cout << "In insertHead" << endl;
    Node *check = mylist;
    while(check != NULL){
			if(check->data == value) {
				return;
			}
      check = check->next;
		}
    Node *ptr = mylist;
    mylist = new Node(value);
    mylist->next = ptr;
		num_items++;
  };

	/*
	insertTail

	A node with the given value should be inserted at the end of the list.

	Do not allow duplicate values in the list.
	*/
	void insertTail(T value) {
    cout << "In insertTail"<<endl;
    Node *check = mylist;
    while(check != NULL){
			if(check->data == value) {
				return;
			}
      check = check->next;
		}
		Node *ptr = mylist;
		if(mylist == NULL){
			mylist = new Node(value, NULL);
		} else {
			while(ptr != NULL){
				if(ptr->next == NULL) {
					ptr->next = new Node(value, NULL);
					break;
				} else {
					ptr = ptr->next;
				}
			}
		}
		num_items++;
  };

	/*
	insertAfter

	A node with the given value should be inserted immediately after the
	node whose value is equal to insertionNode.

	A node should only be added if the node whose value is equal to
	insertionNode is in the list. Do not allow duplicate values in the list.
	*/
	void insertAfter(T value, T insertionNode) {
    cout << "In insertAfter"<<endl;
    Node *check = mylist;
    while(check != NULL){
			if(check->data == value) {
				return;
			}
      check = check->next;
		}
    Node *ptr = mylist;
    while(ptr->data != insertionNode){
			if(ptr->next == NULL) {
				return;
			}
      ptr = ptr->next;
		}
    Node *newnode = new Node(value,NULL);
    newnode->next = ptr->next;
		ptr->next = newnode;
		num_items++;
  };

	/*
	remove

	The node with the given value should be removed from the list.

	The list may or may not include a node with the given value.
	*/
	void remove(T value) {
    cout << "In remove"<<endl;
    if (mylist == NULL) {
      return;
    }
		Node *ptr = mylist;
    if(ptr->data == value) {
			Node *current = mylist;
			mylist = mylist->next;
			delete current;
		  num_items--;
		} else {
      while (ptr->next->data != value) {
		    if(ptr->next->next == NULL) {
				  return;
			  }
        ptr = ptr->next;
		  }
      Node *current = ptr->next;
		  ptr->next = current->next;
		  delete current;
		  num_items--;
    }
  };

	/*
	clear

	Remove all nodes from the list.
	*/
	void clear() {
    cout << "In clear"<<endl;
    while(mylist != NULL) {
			Node *current = mylist;
			mylist = mylist->next;
			delete current;
      num_items--;
		}
  };

	/*
	at

	Returns the value of the node at the given index. The list begins at
	index 0.

	If the given index is out of range of the list, throw an out of range exception.
	*/
	T at(int index) {
    cout << "In at"<<endl;
		if(index >= num_items || index < 0) {
			throw std::out_of_range("At Error");
		} else {
			Node *ptr = mylist;
			for(int i = 0; i <= index; i++) {
				cout << "["<<i<<"]="<<ptr->data<<endl;
		  		if(i == (index)) { 
		  			return(ptr->data);
		  		}else {
		  			ptr = ptr->next;
		  		}
			}
		}
  };

	/*
	size

	Returns the number of nodes in the list.
	*/
	int size() {
    cout << "In size"<<endl;
		return(num_items);
  };

	/*
	toString
	
	Returns a string representation of the list, with the value of each node listed in order (Starting from the head) and separated by a single space
	There should be no trailing space at the end of the string

	For example, a LinkedList containing the value 1, 2, 3, 4, and 5 should return
	"1 2 3 4 5"
	*/
	string toString() {
    cout << "In toString"<<endl;
    stringstream ss;
    for(Node *ptr = mylist; ptr != NULL; ptr = ptr->next) {
			ss << ptr->data;
      if (ptr->next != NULL) {
        ss << " ";
      }
		}
    return(ss.str());
  };

};