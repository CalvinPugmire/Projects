#pragma once

#include <iostream>

#include "NodeInterface.h"

using namespace std;

class Node : public NodeInterface {
  friend class BST;

  private:
    // Data Fields
    int data;
    Node* left;
    Node* right;

  public:
    // Constructor
    Node(const int& the_data) {
      data = the_data;
      left = NULL;
      right = NULL;
    }

	  // Constructor
    /*Node(const int& the_data, Node * left_val = NULL, Node * right_val = NULL) {
      data = the_data;
      left = left_val;
      right = right_val;
    }*/

	  ~Node() {}

	  /*
	  * Returns the data that is stored in this node
	  *
	  * @return the data that is stored in this node.
	  */
	  int getData() const;

	  /*
	  * Returns the left child of this node or null if it doesn't have one.
	  *
	  * @return the left child of this node or null if it doesn't have one.
	  */
	  Node * getLeftChild() const;

	  /*
	  * Returns the right child of this node or null if it doesn't have one.
	  *
	  * @return the right child of this node or null if it doesn't have one.
	  */
	  Node * getRightChild() const;
};