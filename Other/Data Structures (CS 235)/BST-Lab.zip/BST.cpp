#include "BST.h"

NodeInterface* BST::getRootNode() const {
  return root;
};

bool BST::add(int data) {
  cout << "add" << endl;
  Node *p = findLast(data);
  Node *u = new Node(data);
  u->data = data;
  return addChild(p, u);
}

Node * BST::findLast(int data) {
  cout << "findlast" << endl;
  Node *w = root, *prev = NULL;
  while (w != NULL) {
    prev = w;
    int comp = data - w->data;
    if (comp < 0) {
      w = w->left;
    } else if (comp > 0) {
      w = w->right;
    } else {
      return w;
    }
  }
  return prev;
}

bool BST::addChild(Node *p, Node *u) {
  cout << "addchild" << endl;
  if (p == NULL) {
    root = u;              // inserting into empty tree
  } else {
    int comp = u->data - p->data;
    if (comp < 0) {
      p->left = u;
    } else if (comp > 0) {
      p->right = u;
    } else {
      delete u;
      return false;   // u.x is already in the tree
    }
    //u->parent = p;
  }
  return true;
}

bool BST::remove(int data) {
  cout << "remove" << endl;
  return erase(this->root, data);
};

bool BST::erase(Node*& local_root, int data) {
  cout << "erase" << endl;
  if (local_root == NULL) {
    return false;
  } else {
    if (data < local_root->data)
      return erase(local_root->left, data);
    else if (local_root->data < data)
      return erase(local_root->right, data);
    else { // Found item
      Node* old_root = local_root;
      if (local_root->left == NULL) {
        local_root = local_root->right;
      } else if (local_root->right == NULL) {
        local_root = local_root->left;
      } else {
        replace_parent(old_root, old_root->left);
      }
      delete old_root;
      return true;
    }
  }
}

void BST::replace_parent(Node*& old_root, Node*& local_root) {
  cout << "replaceparent" << endl;
  if (local_root->right != NULL) {
      replace_parent(old_root, local_root->right);
  } else {
    old_root->data = local_root->data;
    old_root = local_root;
    local_root = local_root->left;
    //erase(old_root->left, local_root->data);
  }
}

void BST::clear() {
  cout << "clear" << endl;
  freeBST(root);
};

void BST::freeBST(Node*& tree) {
    // Base case: empty tree
    if (tree == NULL) {
        return;
    }
 
    // delete left and right subtree first (Postorder)
    freeBST(tree->left);
    freeBST(tree->right);
 
    // delete the current node after deleting its left and right subtree
    delete tree;
 
    // set root as null before returning
    tree = NULL;
}