#include "AVL.h"

NodeInterface* AVL::getRootNode() const {
  return root;
};

void AVL::rebalance(Node*& node) {
  if (difference(node) == 2 && difference(node->left) == 1) {
    rotateLeft(node);
  }
  else if (difference(node) == 2 && difference(node->left) == -1) {
    rotateLeftRight(node);
  }
  else if (difference(node) == 2 && difference(node->left) == 0) {
    rotateLeft(node);
  }
  else if (difference(node) == -2 && difference(node->right) == -1) {
    rotateRight(node);
  }
  else if (difference(node) == -2 && difference(node->right) == 1) {
    rotateRightLeft(node);
  }
  else if (difference(node) == -2 && difference(node->right) == 0) {
    rotateRight(node);
  }
}

int AVL::difference(Node* node) {
  if (node->left && node->right) {
    return node->left->getHeight() - node->right->getHeight();
  }
  else if (node->left && node->right == NULL) {
    return node->left->getHeight();
  }
  else if (node->left == NULL && node->right) {
    return -node->right->getHeight();
  } else {
    return 0;
  }
}

void AVL::rotateLeft(Node*& node) {
  Node* temp = node->left;
  node->left = temp->right;
  temp->right = node;
  node = temp;
  calcHeight(node->right);
}

void AVL::rotateRight(Node*& node) {
  Node* temp = node->right;
  node->right = temp->left;
  temp->left = node;
  node = temp;
  calcHeight(node->left);
  calcHeight(node);
}

void AVL::rotateLeftRight(Node*& node) {
  Node* temp1 = node;
  Node* temp2 = node->left;
  Node* temp3 = node->left->right;
  temp1->left = temp3->right;
  temp2->right = temp3->left;
  temp3->right = temp1;
  temp3->left = temp2;
  node = temp3;
  calcHeight(temp1);
  calcHeight(temp2);
  calcHeight(temp3);
}

void AVL::rotateRightLeft(Node*& node) {
  Node* temp1 = node;
  Node* temp2 = node->right;
  Node* temp3 = node->right->left;
  temp1->right = temp3->left;
  temp2->left = temp3->right;
  temp3->left = temp1;
  temp3->right = temp2;
  node = temp3;
  calcHeight(temp1);
  calcHeight(temp2);
  calcHeight(temp3);
}

int AVL::getHeight(Node* node) {
  if (node == NULL) {
    return 0;
  } else {
    return node->getHeight();
  }
}

void AVL::calcHeight(Node* node) {
  if (node == nullptr) {
    return;
  }
  int max = 0;
  if (getHeight(node->getLeft()) > max) {
    max = getHeight(node->getLeft());
  }
  if (getHeight(node->getRight()) > max) {
    max = getHeight(node->getRight());
  }
  node->setHeight(max+1);
}

bool AVL::endOfTree(Node*& node) {
  if (node == NULL) {
    return false;
  }
  else {
    calcHeight(node);
    rebalance(node);
    endOfTree(node->left);
    endOfTree(node->right);
  }
}



bool AVL::add(int data) {
  return insert(root, data);
}

bool AVL::insert(Node*& node, int data) {
  if (node == NULL) {
    node = new Node(data);
    return true;
  } else if (node->getData() == data) {
    return false;
  } else if (data < node->getData()) {
    bool returnvalue = insert(node->left, data);
    calcHeight(node);
    rebalance(node);
    return returnvalue;
  } else if (data > node->getData()) {
    bool returnvalue = insert(node->right, data);
    calcHeight(node);
    rebalance(node);
    return returnvalue;
  }
}



bool AVL::remove(int data) {
  return erase(root, data);
}

bool AVL::erase(Node*& node, int data) {
  if (node == NULL) {
    return false;
  } 
  else if (node->data == data) {
    if (node->left == NULL && node->right == NULL) {
      delete node;
      node = NULL;
    }
    else if (node->right == NULL) {
      node->data = node->left->data;
      delete node->left;
      node->left = NULL;
      calcHeight(node);
    }
    else if (node->left == NULL) {
      node->data = node->right->data;
      delete node->right;
      node->right = NULL;
      calcHeight(node);
    } else {
      Node* temp = replaceParent(node->left);
      node->data = temp->data;
      delete temp;
      calcHeight(node);
      temp = NULL;
      if (node == root) {
        endOfTree(node);
      } else {
        rebalance(node);
      }
    }
    return true;
  }
  else if (data < node->getData()) {
    bool returnvalue = erase(node->left, data);
    calcHeight(node);
    rebalance(node);
    return returnvalue;
  }
  else if (node->getData() < data) {
    bool returnvalue = erase(node->right, data);
    calcHeight(node);
    rebalance(node);
    return returnvalue;
  }
}

Node* AVL::replaceParent(Node*& node) {
  if(node->right == NULL){
    Node * temp = node;
    node = node->left;
    return temp;
  } else{
    return replaceParent(node->right);
  }
}



void AVL::clear() {
  free(this->root);
  this->root = NULL;
};

void AVL::free(Node* node) {
    if (node == NULL) {
        return;
    }
    free(node->left);
    free(node->right);
    delete node;
}