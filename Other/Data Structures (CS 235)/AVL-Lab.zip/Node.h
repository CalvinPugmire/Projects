#pragma once

#include <iostream>

#include "NodeInterface.h"

using namespace std;

class Node : public NodeInterface {
  friend class AVL;

  protected:
    // Data Fields
    int data;
    Node* left;
    Node* right;
    int height;

  public:
    // Constructor
    Node(int the_data) {
      data = the_data;
      left = NULL;
      right = NULL;
      height = 1;
    }

	  // Constructor
    /*Node(const int& the_data, Node * left_val = NULL, Node * right_val = NULL) {
      data = the_data;
      left = left_val;
      right = right_val;
    }*/

	  ~Node() {}

	  /*
	  * Returns the data that is stored in this node
	  *
	  * @return the data that is stored in this node.
	  */
	  int getData() const;

	  /*
	  * Returns the left child of this node or null if it doesn't have one.
	  *
	  * @return the left child of this node or null if it doesn't have one.
	  */
	  NodeInterface* getLeftChild() const;

    Node* getLeft();

    void setLeftChild(Node* ptr);

	  /*
	  * Returns the right child of this node or null if it doesn't have one.
	  *
	  * @return the right child of this node or null if it doesn't have one.
	  */
	  NodeInterface* getRightChild() const;

    Node* getRight();

    void setRightChild(Node* ptr);

    /*
	  * Returns the height of this node. The height is the number of nodes
	  * along the longest path from this node to a leaf.  While a conventional
	  * interface only gives information on the functionality of a class and does
	  * not comment on how a class should be implemented, this function has been
	  * provided to point you in the right direction for your solution.  For an
	  * example on height, see page 448 of the text book.
	  *
	  * @return the height of this tree with this node as the local root.
	  */
	  int getHeight();

    void setHeight(int newHeight);
};