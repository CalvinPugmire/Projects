#pragma once

#include <iostream>

#include "AVLInterface.h"

#include "Node.h"

using namespace std;

class AVL : public AVLInterface {
  public:
	  AVL() {
      root = NULL;
    }

	  ~AVL() {
      clear();
    }

	//Please note that the class that implements this interface must be made
	//of objects which implement the NodeInterface

	/*
	* Returns the root node for this tree
	*
	* @return the root node for this tree.
	*/
	  NodeInterface * getRootNode() const;
    
    //void rebalance_left(Node*& local_root);
    //void rebalance_right(Node*& local_root);
    void rebalance(Node*& node);
    int difference(Node* node);
    void rotateLeft(Node*& node);
    void rotateRight(Node*& node);
    void rotateLeftRight(Node*& node);
    void rotateRightLeft(Node*& node);
    int getHeight(Node* node);
    void calcHeight(Node* node);
    bool endOfTree(Node*& node);

	/*
	* Attempts to add the given int to the BST tree
	*
	* @return true if added
	* @return false if unsuccessful (i.e. the int is already in tree)
	*/
	  bool add(int data);
    bool insert(Node*& node, int data);

	/*
	* Attempts to remove the given int from the BST tree
	*
	* @return true if successfully removed
	* @return false if remove is unsuccessful(i.e. the int is not in the tree)
	*/
	  bool remove(int data);
    bool erase(Node*& node, int data);
    Node* replaceParent(Node*& node);

	/*
	* Removes all nodes from the tree, resulting in an empty tree.
	*/
	  void clear();
    void free(Node* node);


  protected:
	  Node* root;
};