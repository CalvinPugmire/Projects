#include <iostream>
#include <vector>
#include "MV.h"
#include "MyVector.h"
#include <string>
using std::cout;
using std::endl;
using std::string;
int main()
{
    vector<int> intvec;
    intvec.push_back(17);
    cout << "Position 0 "<<intvec[0]<<endl;
    cout << "Position 0 "<<intvec.at(0)<<endl;
    
    vector<string> stringvec;
    stringvec.push_back("Hello");
    cout << "Position 0 "<<stringvec[0]<<endl;
    cout << "Position 0 "<<stringvec.at(0)<<endl;
    
    MV<int> intcontainer;
    cout << "Inserting"<<endl;
    intcontainer.put(5);
    cout << "Getting "<<intcontainer.get()<<endl;
    
    MV<string> stringcontainer;
    cout << "Inserting"<<endl;
    stringcontainer.put("Hello");
    cout << "Getting "<<stringcontainer.get()<<endl;
    
    /*MyVector<int> myvecint;
    myvecint.push_back(5);
    myvecint.insertAt(0, 6);
    cout << "Size "<<myvecint.size()<<endl;
    myvecint.remove(0);
    cout << "Zero " << myvecint.at(0)<<endl;*/
    
    MyVector<int> myvecint;
    myvecint.push_back(5);
    cout << "at 0 "<<myvecint.at(0)<<endl;
    cout << "Size "<<myvecint.size()<<endl;
    myvecint.push_back(10);
    cout << "at 1 "<<myvecint.at(1)<<endl;
    cout << "Size "<<myvecint.size()<<endl;
    myvecint.push_back(15);
    cout << "at 2 "<<myvecint.at(2)<<endl;
    cout << "Size "<<myvecint.size()<<endl;
    myvecint.push_back(20);
    cout << "at 3 "<<myvecint.at(3)<<endl;
    cout << "Size "<<myvecint.size()<<endl;
    myvecint.push_back(25);
    cout << "at 4 "<<myvecint.at(4)<<endl;
    cout << "Size "<<myvecint.size()<<endl;
    for(int i = 0; i < 5; i++) {
      cout <<"["<<i<<"]="<<myvecint.at(i);
    }

    myvecint.insertAt(0, 6);
    cout <<"after insertAt"<<endl;
    for(int i = 0; i < myvecint.size(); i++) {
        cout <<"["<<i<<"]="<<myvecint.at(i);
    }
    cout << "Size "<<myvecint.size()<<endl;

    myvecint.remove(0);
    cout <<"after remove"<<endl;
    for(int i = 0; i < myvecint.size(); i++) {
        cout <<"["<<i<<"]="<<myvecint.at(i);
    }
    cout << "Size "<<myvecint.size()<<endl;
}

