#include "Hashmap.h"

Hashmap::Hashmap() {
  mapSize = 0;
  for (int i = 0; i < BUCKETS; i++)
    buckets[i] = NULL;
}

Hashmap::~Hashmap() {
  clear();
}

void Hashmap::insert(string key, int value) {
  //cout << "insert" << endl;
  int& valptr = at(key);
  valptr = value;
}

bool Hashmap::contains(string key) const {
  //cout << "contains" << endl;
  int hashval = hash(key); // Compute the hash value for this name, for now assume it is 0
	Node *ptr = buckets[hashval];
	while(ptr != NULL) {
		// cout <<"comparing "<<name<<" first "<<ptr->context.first<<endl;
		if(key == ptr->key) { // We found it
			return true;
		} else {
		  //cout << "ptr"<< ptr<<"next "<< ptr->next<<endl;
		  ptr = ptr->next;
		}
	}
  return false;
}

int Hashmap::get(string key) const {
  //cout << "get" << endl;
  int hashval = hash(key); // Compute the hash value for this name, for now assume it is 0
	Node *ptr = buckets[hashval];
	while(ptr != NULL) {
		// cout <<"comparing "<<name<<" first "<<ptr->context.first<<endl;
		if(key == ptr->key) { // We found it
			return ptr->value;
		} else {
		  //cout << "ptr"<< ptr<<"next "<< ptr->next<<endl;
		  ptr = ptr->next;
		}
	}
  if (ptr == NULL)
    throw invalid_argument ("message");
  return 0;
}

int& Hashmap::operator[] (string key) {
  //cout << "operator" << endl;
  return at(key);
}

int& Hashmap::at(string name) {
  //cout << "at" << endl;
  int hashval = hash(name); // Compute the hash value for this name, for now assume it is 0
	Node* ptr = buckets[hashval];
  Node* prevptr = buckets[hashval];
  int prevptrcnt = 0;
	while(ptr != NULL) {
		// cout <<"comparing "<<name<<" first "<<ptr->context.first<<endl;
		if(name == ptr->key) { // We found it
			break;
		} else {
		  //cout << "ptr"<< ptr<<"next "<< ptr->next<<endl;
		  ptr = ptr->next;
      prevptrcnt = prevptrcnt + 1;
		}
	}
	if(ptr == NULL) { // We need to create a new node, put it on the front of the list
    mapSize = mapSize + 1;
		ptr = new Node;
		//cout << "new node "<< static_cast<void*>(&(ptr->context.second))<<endl;
		ptr->next = buckets[hashval];
		buckets[hashval] = ptr;
		ptr->key = name;
    if (ptr->next != NULL)
      ptr->next->prev = ptr;
    for (int i = 0; i < prevptrcnt; i++) {
      prevptr = prevptr->next;
    }
    ptr->prev = prevptr;
	}
	//cout << "return "<< static_cast<void*>(&(ptr->context.second))<<endl;
	return(ptr->value);
}

bool Hashmap::remove(string key) {
  //cout << "remove" << endl;
  unsigned int bucket = hash(key);
  Node* current = buckets[bucket];
  while ((current != NULL) && (current->key != key)) {
    current = current->next;
  }
  if (current == NULL) {
    return false;
  }
  if (current->next != NULL) {
    current->next->prev = current->prev;
  }
  if (current->prev == NULL) {
    buckets[bucket] = current->next;
  } else {
    current->prev->next = current->next;
  }
  delete current;
  mapSize = mapSize - 1;
  return true;
}

void Hashmap::clear() {
  //cout << "clear" << endl;
  for (int i = 0; i < BUCKETS; i++) {
    Node* current = buckets[i];
    while(current != NULL) {
      if(current->next != NULL) {
        current->next->prev = NULL;
      }
      buckets[i] = current->next;
      delete current;
      mapSize = mapSize - 1;
      current = buckets[i];
    }
  }
}

string Hashmap::toString() const {
  //cout << "tostring" << endl;
  stringstream ss;
  for (int i = 0; i < BUCKETS; i++) {
    Node* head = buckets[i];
    if (head == NULL) { //bucket is empty
      ss << "["<<i<<"]" << endl;
    } else { //bucket isn't empty
      Node* current = head;
      ss << "["<<i<<"]";
      while (current != NULL) {
        ss << current->key << " => " << current->value;
        if (current->next != NULL)
          ss << ", ";
        current = current->next;
      }
      ss << endl;
    }
  }
  return ss.str();
}

int Hashmap::size() const {
  //cout << "size" << endl;
  return mapSize;
}

string Hashmap::toSortedString() const {
  //cout << "tosortedstring" << endl;
  stringstream ss;
  priority_queue<Node*, vector<Node*>, NodeCompare> nodeHeap;
  for (int i = 0; i < BUCKETS; i++) {
    Node* current = buckets[i];
    while (current != NULL) {
      nodeHeap.push(current);
      current = current->next;
    }
  }
  while (!nodeHeap.empty()) {
    Node* top = nodeHeap.top();
    ss << top->key << " => " << top->value << endl;
    nodeHeap.pop();
  }
  return ss.str();
}

unsigned int Hashmap::hash(string key) const {
  //cout << "hash" << endl;
  unsigned int hashCode = 0;
  for (int i = 0; i < key.length(); i++) {
    hashCode = hashCode * 31 + key.at(i);
  }
  return hashCode % BUCKETS;
}