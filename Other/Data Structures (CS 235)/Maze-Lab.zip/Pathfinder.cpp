#include "Pathfinder.h"
	string Pathfinder::toString() const
	{
	    stringstream ss;
	    for(int dep = 0; dep < ROW_SIZE; dep++) {
			  for(int row = 0; row < COL_SIZE; row++) {
				  for(int col = 0; col < DEP_SIZE; col++) {
            if (col != 4) {
				      ss << maze_grid[row][col][dep] << " ";
            }
            else
              ss << maze_grid[row][col][dep];
			    }
			    ss << endl;
			  }
        if (dep != 4)
			    ss << endl;
	    }
	    return ss.str();

      srand(1);
	}

	/*
	* createRandomMaze
	*
	* Generates a random maze and stores it as the current maze.
	*
	* The generated maze must contain a roughly equal number of 1s and 0s and must have a 1
	* in the entrance cell (0, 0, 0) and in the exit cell (4, 4, 4).  The generated maze may be
	* solvable or unsolvable, and this method should be able to produce both kinds of mazes.
	*/
	void Pathfinder::createRandomMaze()
	{
    for(int row = 0; row < ROW_SIZE; row++) {
			for(int col = 0; col < COL_SIZE; col++) {
				for(int dep = 0; dep < DEP_SIZE; dep++) {
					maze_grid[row][col][dep] = rand()%2;
				}
			}
		}
    maze_grid[0][0][0] = 1;
    maze_grid[4][4][4] = 1;
	}
	//-----------------------------------------------------------------------------------------

	//Part 2-----------------------------------------------------------------------------------
	/*
	* importMaze
	*
	* Reads in a maze from a file with the given file name and stores it as the current maze.
	* Does nothing if the file does not exist or if the file's data does not represent a valid
	* maze.
	*
	* The file's contents must be of the format described above to be considered valid.
	*
	* Parameter:	file_name
	*				The name of the file containing a maze
	* Returns:		bool
	*				True if the maze is imported correctly; false otherwise
	*/
	bool Pathfinder::importMaze(string file_name)
	{
    cout << "importMaze from "<<file_name<<endl;
		ifstream file (file_name.c_str());
		if (file.is_open()) {
      int map_copy [5][5][5];
      string line;
			for(int dep = 0; dep < ROW_SIZE; dep++) {
				for(int row = 0; row < COL_SIZE; row++) {
          getline(file, line);
				  stringstream ss(line);
          if (file.bad() || file.fail()) {
            cout << "Too short." << endl;
            return false;
          }
					for(int col = 0; col < DEP_SIZE; col++) {
            if (line.find('a') != std::string::npos) {
              cout << "Bad input." << endl;
              return false;
            }
					  int value = 0;
					  ss >> value;
            if (file.fail()) {
              cout << "Bad input." << endl;
              return false;
            }
            if (value != 0 && value != 1) {
              cout << "Bad input." << endl;
              return false;
            }
					  map_copy[row][col][dep] = value;
				  }
				}
        getline(file, line);
			}
      ifstream filetest (file_name.c_str()); 
      string str;
      int count = 0;
      while( filetest >> str ){
        count++;
      }
      if (count != 125) {
        cout << "Too long or short" << endl;
        return false;
      }
      if (map_copy[0][0][0] != 1 || map_copy[4][4][4] != 1) {
        cout << map_copy[0][0][0] << endl;
        cout << map_copy[4][4][4] << endl;
        cout << "No entry or exit." << endl;
        return false;
      }
			for(int row = 0; row < ROW_SIZE; row++) {
				for(int col = 0; col < COL_SIZE; col++) {
					for(int dep = 0; dep < DEP_SIZE; dep++) {
					  maze_grid[row][col][dep] = map_copy[row][col][dep];
				  }
				}
			}
      return(true);
		}
	  return(false);
	}
	//-----------------------------------------------------------------------------------------

	
	
	bool Pathfinder::find_maze_path(int grid[COL_SIZE][ROW_SIZE][DEP_SIZE], int c, int r, int d) {
	  cout << "find_maze_path ["<<c<<"]["<<r<<"]["<<d<<"]"<<endl;
	  cout << this->toString();
	  if (c < 0 || r < 0 || d < 0 || c >= COL_SIZE || r >= ROW_SIZE || d >= DEP_SIZE)
	    return false;      // Cell is out of bounds.
	  else if (grid[c][r][d] != BACKGROUND)
	    return false;      // Cell is on barrier or dead end.
	  else if (c == COL_SIZE - 1 && r == ROW_SIZE - 1 && d == DEP_SIZE - 1) {
	    grid[c][r][d] = PATH;         // Cell is on path
	    solution.insert(solution.begin(), "("+to_string(r)+", "+to_string(c)+", "+to_string(d)+")");
	    return true;               // and is maze exit.
	  }
	  else { 
	    // Recursive case.
	    // Attempt to find a path from each neighbor.
	    // Tentatively mark cell as on path.
	    grid[c][r][d] = PATH;
      if (c == COL_SIZE - 1 && r == ROW_SIZE - 1 && d == DEP_SIZE - 1) {
        return true;
      }
	    if (find_maze_path(grid, c - 1, r, d)
	        || find_maze_path(grid, c + 1, r, d)
	        || find_maze_path(grid, c, r - 1, d)
	        || find_maze_path(grid, c, r + 1, d)
          || find_maze_path(grid, c, r, d - 1)
          || find_maze_path(grid, c, r, d + 1) ) {
	      solution.insert(solution.begin(), "("+to_string(r)+", "+to_string(c)+", "+to_string(d)+")");
	      return true;
	    }
	    else {
	      grid[c][r][d] = TEMPORARY;  // Dead end.
	      return false;
	    }
	  }
	}
	  //Part 3-----------------------------------------------------------------------------------
	/*
	* solveMaze
	*
	* Attempts to solve the current maze and returns a solution if one is found.
	*
	* A solution to a maze is a list of coordinates for the path from the entrance to the exit
	* (or an empty vector if no solution is found). This list cannot contain duplicates, and
	* any two consecutive coordinates in the list can only differ by 1 for only one
	* coordinate. The entrance cell (0, 0, 0) and the exit cell (4, 4, 4) should be included
	* in the solution. Each string in the solution vector must be of the format "(x, y, z)",
	* where x, y, and z are the integer coordinates of a cell.
	*
	* Understand that most mazes will contain multiple solutions
	*
	* Returns:		vector<string>
	*				A solution to the current maze, or an empty vector if none exists
	*/
	
	vector<string> Pathfinder::solveMaze()
	{
    solution.clear();
		find_maze_path(maze_grid, 0,0,0);
		for(auto s:solution) {
			cout << s << endl;
		}
    for(int row = 0; row < ROW_SIZE; row++) {
				for(int col = 0; col < COL_SIZE; col++) {
					for(int dep = 0; dep < DEP_SIZE; dep++) {
            if (maze_grid[row][col][dep] != 0)
					    maze_grid[row][col][dep] = 1;
				  }
				}
			}
	  return solution;
	}