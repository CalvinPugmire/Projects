#include "QS.h"
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>



bool QS::createArray (int capacity) {
  if (capacity < 1) {
    return false;
  }
  if (table != 0) {
    delete [] table; 
    table = nullptr;
  } 
  table = new int [capacity];
  size = capacity;
  count = 0;
  return true;
}

bool QS::addToArray (int value) {
  if (count >= size) {
    return false;
  }
  else {
    table[count] = value;
    count++;
    return true;
  }
}

string QS::getArray() const {
  if (count == 0) {
    return "";
  }
  else {
    ostringstream os;
    for (int i = 0; i < count-1; i++) {
      os << (table[i]) << ",";
    }
    os << table[count-1];
    string tableString = os.str();
    os.str("");
    os.clear();
    return tableString;
  }
}

int QS::getSize() const {
  return count;
}

void QS::clear() {
  delete [] table;
  table = nullptr;
  size = 0;
  count = 0;
}

int QS::medianOfThree(int left, int right) {
  if ((count == 0) || (left < 0) || (left >= count) || (right < 0) || (right >= count) || (left >= right)) {
    return -1;
  }
  int middle = (left+right)/2;
  int tmp;
  if (table[left] > table[middle]) {
    tmp = table[left];
    table[left] = table[middle];
    table[middle] = tmp;
  }
  if (table[right] < table[middle]) {
    tmp = table[right];
    table[right] = table[middle];
    table[middle] = tmp;
  }
  if (table[middle] < table[left]) {
    tmp = table[middle];
    table[middle] = table[left];
    table[left] = tmp;
  }
  return middle;
}

int QS::partition(int left, int right, int pivotIndex) {
  if ((count == 0) || (left < 0) || (left >= count) || (right < 0) || (right >= count) || (left >= right) || (left > pivotIndex) || (right < pivotIndex)) {
    return -1;
  }
  int tmp = table[pivotIndex];
  table[pivotIndex] = table[left];
  table[left] = tmp;
  int up = left+1;
  int down = right;
  do {
    while ((table[up] <= table[left]) && (up < right)) {
      up++;
    }
    while ((table[down] > table[left]) && (down > left)) {
      down--;
    }
    if (up < down) {
      tmp = table[up];
      table[up] = table[down];
      table[down] = tmp;
    }
  } while (up < down);
  tmp = table[left];
  table[left] = table[down];
  table[down] = tmp;
  return down;
}

void QS::quickSort(int left, int right) {
  if ((right-left) < 1) {
    return;
  }
  int pivot = medianOfThree(left, right);
  pivot = partition(left, right, pivot);
  quickSort(left, pivot-1);
  quickSort(pivot+1, right);
}

void QS::sortAll() {
  if (count == 0) {
    return;
  }
  quickSort(0, count-1);
}